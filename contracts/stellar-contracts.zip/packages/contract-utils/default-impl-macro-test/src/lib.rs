//! This crate is a test crate for the default-impl-macro.
//! Proc-macros cannot be tested within their own crate due to Rust's
//! limitations, hence a separate crate for testing is used for testing the
//! proc-macro.
//!
//! This crate is not intended for use in any other context. And this `lib.rs`
//! file is empty on purpose.
