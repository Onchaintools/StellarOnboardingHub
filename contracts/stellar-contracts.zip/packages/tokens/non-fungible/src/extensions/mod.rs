pub mod burnable;
pub mod consecutive;
pub mod enumerable;
pub mod royalties;
