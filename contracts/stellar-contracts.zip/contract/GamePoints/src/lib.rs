#![no_std]
#![allow(dead_code)]

mod contract;